package sjsu.cs146.twoThreeTree;

public class TwoThreeTreeTester 
{
   public static void main(String [] args)
   {
   TwoThreeTree a = new TwoThreeTree();
   
   a = a.insert(24);
   a = a.insert(49);
   a = a.insert(24);
   a = a.insert(30);
   a = a.insert(16);
   a = a.insert(50);
   a = a.insert(69);
   a = a.insert(69);
   a = a.insert(10);
   a = a.insert(5); 
   a = a.insert(4);
   a = a.insert(77); 
   a = a.insert(100);
   a = a.insert(65);
   a = a.insert(59);
   a = a.insert(25);
   a = a.insert(75);
   a = a.insert(115);
   a = a.insert(43);
   //a = a.insert(99);
   a = a.insert(17);
   a = a.insert(31);
   a = a.insert(35);
   a = a.insert(39);//this is where it is known good to
   a = a.insert(45);
   a = a.insert(200); //good to here
   a = a.insert(70);
   a = a.insert(44);
   a = a.insert(97);
   a = a.insert(44);
   a = a.insert(1);
   a = a.insert(245);
   a = a.insert(12);
   a = a.insert(29);
   a = a.insert(27);
   a = a.insert(6);
   a = a.insert(15);
   a = a.insert(87);
   a = a.insert(79);
   a = a.insert(83);
   a = a.insert(400);
   a = a.insert(55);
   a = a.insert(367);
   a = a.insert(255);
   a = a.insert(333);
   a = a.insert(154);
   a = a.insert(175);
   a = a.insert(299);
   a = a.insert(267);
   a = a.insert(294);
   a = a.insert(3);
   a = a.insert(2);
   a = a.insert(11);
   
   
   }
}
