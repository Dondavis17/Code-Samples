package sjsu.cs146.twoThreeTree;

import java.util.*;

public class TwoThreeTree 
{
   //TwoThreeTree root;
   TwoThreeTree left;
   TwoThreeTree right;
   TwoThreeTree mid;
   TwoThreeTree parent;
   TwoThreeTree q;
   private ArrayList < Integer > values = new ArrayList < Integer > ();

   
   public TwoThreeTree()
   {
     // root = this;
      
      parent = this;
      left = null;
      mid = null;
      right = null;
      q = null;
      /**
      values.add(data);
      values.trimToSize();
      treeSearch(int data);**/
   }
   public String treeSearch(int data)
   {  
      if (values.isEmpty()) //checks for initial node
         return null;
      
      else if (values.contains(data)) //checks if node contains data
         return getString(values);
      
      else if (data < values.get(0))  
      { //checks if data is less than the 0 index of values in left hand nodes
         if (left == null)
            return getString(values);
         else //owe child support (recursive call to next lvl
            return left.treeSearch(data);
      }
      else if (1 == values.size()) //checks size of values in node is == to 1
      {
         if (left == null)  //checks for children
            return getString(values);
         
         else
            return right.treeSearch(data);
      }
      else //this returns the values in values if there is more than one value 
      { //this traverses the right or far right side of the tree
         if (left == null)
            return getString(values);
         
         else if (data < values.get(1))
            return mid.treeSearch(data);
         
         else
            return right.treeSearch(data); //.values.get(2).treeSearch(data);
      }
   }
   public TwoThreeTree insert(int data)
   {
      if (values.isEmpty())
      {
         addValue(data);
         return this;
      }
      else
      {     
         if (!exists(data))
         {
            
            if (left == null) //if this is a leaf
               return split(data);

            else if (left != null)
            {
               TwoThreeTree temp = new TwoThreeTree();
               //checks if data is less than left most value and inserts if it is  
               if(data < values.get(0))
                  temp = left.insert(data);
               
               else if (mid != null)
               { //checks for mid child and traverses if between values
                  if (data > values.get(0) && data < values.get(1))
                     temp = mid.insert(data);
                  else //traverses right if greater than last value
                     temp = right.insert(data);
               }
               else //traverses the right child if no mid
                  temp = right.insert(data);
               
               if (temp.parent != this)
               { //popcorn node(the node was popped up) lose temp.right here
                  left.parent = this;
                  right.parent = this;
                  if (mid != null)
                     mid.parent = this;
                                 
                  if (1 == values.size()) 
                  { //this is parent node and checks for the value of temp parent against
                     if(temp.values.get(0) < values.get(0)) 
                     {
                        mid = temp.right;
                        if(temp.left.left != null)
                           left = temp.left;
                        return split(temp.values.get(0));
                     }
                     else if (temp.values.get(0) == values.get(0))
                        return this;
                     else //if ( values.size() == 2)
                     {
                        mid = temp.left;
                        mid.parent = this;
                        right = temp.right; //added this line to fix right node
                        right.parent = this;
                        return split(temp.values.get(0));
                     }
                  }
                  else if( !this.exists(temp.values.get(0)) ) //this is for all the playas
                  {   
                     
                     if (temp.values.get(0) < values.get(0))
                     {
                        q = temp.left;
                        left = temp.right;
                        left.parent = this;
                        q.parent = this;
                        return split(temp.values.get(0));
                     }
                     else if (values.get(0) < temp.values.get(0) 
                           && temp.values.get(0) < values.get(1))
                     {
                        q = left;
                        left = temp.left;
                        mid = temp.right;
                        left.parent = this;
                        q.parent = this;
                        mid.parent = this;
                        return split(temp.values.get(0));
                     }
                     else
                     {
                        q = left;
                        left = mid;
                        mid = temp.left;
                        right = temp.right;
                        left.parent = this;
                        q.parent = this;
                        mid.parent = this;
                        right.parent = this;
                        return split(temp.values.get(0));
                     }
                  }
                  else
                     return this;
               }
            }
         }
         return this;
      }
   }
   public TwoThreeTree split(int data)
   {
      if (values.size() < 3) //if we can just insert the value
      { 
         addValue(data);
         
         if (values.size() == 3) //if the node is full, split it  
         {
               TwoThreeTree temp = new TwoThreeTree();
               temp.parent = temp;
               temp.addValue(values.get(PKEY));
               temp.parent.right = new TwoThreeTree();  //added parent to see if i get correct right value
               temp.parent.right.addValue(values.get(2)); //added parent to see if i get correct right value
               temp.right.parent = temp; //may need to attach to this
               
               values.remove(1);
               values.remove(1);
               
               if (q == null)
               {
                  temp.left = this;
                  temp.left.parent = temp;
               }/**
               else if (parent.values.size() == 2)
               {
                  temp.left = new TwoThreeTree();
                  
                  temp.q = this;
                  temp.left = temp.right;
                  
                  
               }**/
               else
               {  //building new tree
                  temp.left = new TwoThreeTree();
                  temp.left.addValue(values.get(0)); //sets left child 
                  temp.left.left = q;  //sets left grand child (leaf)
                  q = null;  //gets rid of q in the tree
                  temp.left.right = left; //sets right grand child (leaf)
                  temp.right.parent = temp; //sets temp as parent of right child
                  temp.right.right = right; //sets rights right grand child (far right leaf)
                  temp.right.left = mid; //sets rights left grand child
                  mid = null; //gets rid of mid node
                  temp.right.right.parent = temp.right; //sets right grand childs parent
                  temp.right.left.parent = temp.right; //sets right childs left childs parent
                  temp.left.parent = temp; //sets left childs parent
                  temp.left.right.parent = temp.left; //sets lefts right grand childs parent
                  temp.left.left.parent = temp.left; //sets lefts left grand childs parent
                  //left = null;
                  //right = null;
               }
               return temp.parent;
         }
      }
      return this.parent;
   }
  
   //public TwoThreeTree merge(TwoThreeTree node)
   {
      
      //return node;
   }
   public void addValue(int data)
   {
      values.add(data);
      values.trimToSize();
      Collections.sort(values);
   }
   public boolean exists(int data)
   { //splits the string into a string array of numbers
      String str[] = treeSearch(data).split(" "); 
      
      for (int i = 0; i < str.length; i++)  //traverses the array
      { //parses the string #'s into integers and checks against data
         if (data == Integer.parseInt(str[i])) 
            return true; 
      }
      return false;  //returns false if no match
   }
   private static String getString(ArrayList < Integer > strData)
   {
      String balls = "";
      for (int i = 0; i < strData.size(); i++)
      {
         if (i == 1)
            balls += " ";
         balls += Integer.toString(strData.get(i));
      }
      return balls;
   }
   private final int PKEY = 1;        
         
}
